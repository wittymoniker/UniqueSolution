# UniqueSolution
 Solves my functions for me. KEEP OUT lol.
